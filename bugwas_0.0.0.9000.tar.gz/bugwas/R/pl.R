.pl = function(name,expr) {
  system.time({
    png(paste0(name,".png"),width=18,height=18,units="cm",pointsize=6,res=600)
    expr
    dev.off()
  })
}