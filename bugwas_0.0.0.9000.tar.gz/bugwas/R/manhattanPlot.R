# Mahattan plot
.manhattanPlot = function(prefix = NULL,
                         snpPos = NULL,
                         snpType = NULL,
                         pValues = NULL,
                         main = NULL,
                         col = NULL,
                         xlab = "Position in reference genome"){ #c(COL,COL2)
  
  .pl(prefix,{
    
    plot(x = snpPos,
         y = pValues,
         col = col, 
         pch = snpType,
         xlab=xlab, ylab="-log10(p-value)",
         main = main)
  })
  
}