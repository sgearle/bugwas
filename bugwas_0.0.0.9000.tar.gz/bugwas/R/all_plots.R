#' Generates all plots.
#' 
#' This function generates all the plots
#' @param biallelic A list called 'biallelic' created from the bugwas function
#' @param triallelic A list called 'triallelic' created from the bugwas function
#' @param genVars A list called 'genVars' created from the bugwas function
#' @param treeInfo A list called 'treeInfo' created from the bugwas function
#' @param config A list called 'config' created from the bugwas function
#' @keywords plot
#' @export
#' @examples
#' all_plots()
all_plots = function(biallelic = NULL,
                     triallelic = NULL,
                     genVars = NULL,
                     treeInfo = NULL,
                     config = NULL){
  
  
  .createAllPlots(prefix = config$prefix,
                 genVars = genVars,
                 cutoffCor = config$cutoffCor,
                 npcs = biallelic$npcs,
                 phenotype = biallelic$pheno,
                 pca = biallelic$pca,
                 fit.lm = biallelic$logreg,
                 fit.lmm = biallelic$lmm,
                 fit.lm.tritetra = triallelic$logreg,
                 fit.lmm.tritetra = triallelic$lmm,
                 gemma = biallelic$lmm,
                 gemma.tritetra = triallelic$lmm,
                 ipat = biallelic$pattern,
                 ipat.snps = triallelic$pattern,
                 pred2 = biallelic$pred,
                 cor.XX = biallelic$cor.XX,
                 cor.tritetra = triallelic$cor.tritetra,
                 which.pc =  biallelic$cor.XX$which.pc,
                 max.cor.pc = biallelic$cor.XX$max.cor.pc,
                 which.pc.tritetra = triallelic$cor.tritetra$which.pc,
                 max.cor.pc.tritetra = triallelic$cor.tritetra$max.cor.pc,
                 which.mtp.pc = treeInfo$cor.tree$which.pc,
                 max.mtp.cor.pc = treeInfo$cor.tree$max.cor.pc,
                 XX.comid = biallelic$id,
                 pc_order = biallelic$pc_order,
                 o = biallelic$pc_order$pc_order,
                 pc.lim = biallelic$pc_order$pc.lim,
                 p.pca.bwt = biallelic$p.pca.bwt,
                 signifCutOff = config$signif_cutoff,
                 bippat = biallelic$bippat,
                 snppat = triallelic$snppat,
                 tree = treeInfo$tree,
                 treepat = treeInfo$pattern);
  
}





