#' Barplot of Bayesian Wald Test on principal components
#' 
#' This function generates the barplot of Bayesian Wald Test on principal components.
#' @param biallelic A list called 'biallelic' created from the bugwas function. It is a required input.
#' @param config A list called 'config' created from the bugwas function. It is a required input.
#' @param treeInfo A list called 'treeInfo' created from the bugwas function. It is a required input.
#' @param colourPalette A vector of colours colour the significant principal components identified by the Bayesian Wald test (see testGenomeWidePCs). If this is NULL then colours are chosen from a default colour palette.
#' @param p.genomewidepc A matrix of the significant principal component and their correlation with lineages. This is Bayesian Wald test results produced by the function testGenomeWidePCs. If this is NULL then testGenomeWidePCs is called to generate the required test results. 
#' @keywords plot
#' @export
#' @examples
#' testGenomeWidePCs(config = config, biallelic = biallelic)
bayesianWaldTestPCsBarplot = function(config, biallelic, treeInfo, colourPalette = NULL, p.genomewidepc = NULL){
	
	if(is.null(colourPalette)){
		colourPalette = getColourPalette(p.pca.bwt = biallelic$p.pca.bwt, signifCutOff = config$signif_cutoff, pc.lim = biallelic$pc_order$pc.lim)	
	}
	
	if(is.null(p.genomewidepc)){
		p.genomewidepc = testGenomeWidePCs(config = config, biallelic = biallelic)
	}
	
	o = biallelic$pc_order$pc_order
	which.mtp.pc = treeInfo$cor.tree$which.pc
	pc.lim = biallelic$pc_order$pc.lim
	m = match(o[pc.lim], which.mtp.pc)
	
	.BayesianWaldTestPCsBarplot(prefix = config$prefix,
                             p.pca.bwt = biallelic$p.pca.bwt,
                             colourPalette = colourPalette,
                             o = o,
                             m = m,
                             p.genomewidepc = p.genomewidepc,
                             pc.lim = biallelic$pc_order$pc.lim)

	
}

.BayesianWaldTestPCsBarplot = function(prefix = NULL,
                                      p.pca.bwt = NULL,
                                      colourPalette = NULL,
                                      o = NULL,
                                      m = NULL,
                                      p.genomewidepc = NULL,
                                      pc.lim = NULL){
  
  barDensity = rep(NA, length(colourPalette))
  barDensity[which(is.na(m) == TRUE)] = 30
  
  # Barplot of Bayesian Wald Test for PCs
  .pl(paste0(prefix,"_barplot_BayesianWald_PCs"),{
    b=barplot(as.vector(p.pca.bwt[o][1:20]),
              col = colourPalette,
              xlab = "Principal Component", ylab = "-log10(p-value)",
              main="Bayesian Wald Test", names=o[1:20],
              cex.lab=1.5, cex.axis=1.5,cex.main=2)
  
    colourPalette2 = colourPalette
    colourPalette2[which(is.na(m)==TRUE)]="black"
    b = barplot(as.vector(p.pca.bwt[o][1:20]),
              col=colourPalette2, xlab="",
              main="Bayesian Wald Test",
              cex.lab=1.5,cex.axis=1.5, 
              names=o[1:20],cex.main=2,
              density=barDensity, add=TRUE, axes=FALSE)
  
    if(length(pc.lim)>0){
      text(b,as.vector(p.pca.bwt[o][1:20]), 
           ifelse(as.numeric(p.genomewidepc[,2])>=2 & as.numeric(p.genomewidepc[,2])<5,"*",""),
           pos=3, cex=2, xpd=NA)
      text(b,as.vector(p.pca.bwt[o][1:20]),
           ifelse(as.numeric(p.genomewidepc[,2])>=5,"**",""),
           pos=3, cex=2, xpd=NA)
      legend("topright",
             c("Non genome-wide PCs","",
               expression(paste("*    ",italic('p')," ≤ 0.01"),collapse=""),
               expression(paste("**  ",italic('p')," ≤ 1e-5",collapse=""))), 
             bty="n",cex=2)
    }
    
  })
}