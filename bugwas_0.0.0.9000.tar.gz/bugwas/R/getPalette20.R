getPalette20 = function(){
	return(c("#529F3D","#5EA0CA","#FE8911",
	"#FFFF99","#A6CEE3","#EB914E",
	"#FDAA4B","#A180BC","#F57F7E",
	"#E93B3C","#6F439D","#267DB1",
	"#B09899","#E94531","#61B74E",
	"#BB9B76","#74B39B","#CFACBF",
	"#F79C5D","#A4D880"))
}