#' Plot of the sample on the first two principal components
#' 
#' This function generates a plot of the sample on the first two principal components.
#' @param biallelic A list called 'biallelic' created from the bugwas function. It is a required input.
#' @param config A list called 'config' created from the bugwas function. It is a required input.
#' @keywords Reduced space plot
#' @export
#' @examples
#' plotIndividualBy2PCs(biallelic = biallelic, config = config)
plotIndividualBy2PCs = function(biallelic = NULL, config = NULL){
	o = biallelic$pc_order$pc_order
	pca = biallelic$pca
	# Plot the individuals by their top two significant additive PCs
  .plotIndividualBy2PCs(pc1 = o[1], pc2 = o[2],
                       pc1.scores = pca$x[,o[1]], pc2.scores = pca$x[,o[2]],
                       prefix= config$prefix, phenotype = biallelic$pheno)
	
}

# Plot the individuals by their top two significant additive PCs
.plotIndividualBy2PCs = function(pc1 = NULL, #o[1]
                                pc2 = NULL, #o[2]
                                pc1.scores = NULL,#pca$x[,o[1]]
                                pc2.scores = NULL, #pca$x[,o[2]]
                                prefix= NULL,
                                phenotype = NULL){ # prefix,"_",name,"
  
  
  .pl(paste0(prefix,"_indiv_first2signifPCs"),{
    # Plot the individuals on the first two additive value PCs
    plot(pc1.scores+rnorm(length(pc1.scores), 0, sd(pc1.scores)/10),
         pc2.scores+rnorm(length(pc2.scores), 0, sd(pc2.scores)/10),
         col=c("blue","red")[1+phenotype], lwd=.5, cex=1.5 ,
         xlab = paste0("PC ",pc1), ylab=paste0("PC ",pc2))
  })
  
}