# Get a random sample of colours to use for all plots, equal to the number of significant PCs
getColourPalette = function(colourCount = 20, p.pca.bwt, signifCutOff, pc.lim, palette = NULL){
	randomCOL=rep("grey50",colourCount) #maybe fix the 20 colours
	
	if(is.null(palette)){
		palette = getPalette20()
		
	}
	
	if(length(palette) < length(pc.lim)){
		stop("Not enough colours provided in the palette (", length(palette),")for colouring significant PCs (", length(pc.lim),").")
	}
  	
  	if(length(which(p.pca.bwt >= signifCutOff))>0){
    	randomCOL[pc.lim] = palette[1:length(pc.lim)]
  	}
  	
  	return(randomCOL)
	
}