# Get tree patterns
.tree2patterns = function(tree,tiporder=tree$tip.label) {
  n = length(tree$tip.label)
  mtp = matrix(0,n,n+tree$Nnode)
  mtp[,1:n] = diag(n)
  for(i in 1:tree$Nnode) {
    wh = match(extract.clade(tree,n+i)$tip.label,tree$tip.label)
    mtp[wh,n+i] = 1
  }
  mtp = mtp[match(tiporder,tree$tip.label),]
  mtp.f = apply(mtp,2,mean)
  mtp[,mtp.f>0.5] = 1-mtp[,mtp.f>0.5]
  mtp.f = apply(mtp,2,mean)
  rownames(mtp) = tiporder
  colnames(mtp) = paste("Node",1:ncol(mtp),sep="_")
  edge = match(1:ncol(mtp),tree$edge[,2])
  edge.length = tree$edge.length[edge]
  return(list("pat"=mtp,"ancestral_edge"=edge,"ancestral_edge.length"=edge.length))
}